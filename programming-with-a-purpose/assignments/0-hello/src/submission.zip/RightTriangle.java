public class RightTriangle {
    public static void main(String[] args) {
        // Parse sides
        long a = Long.parseLong(args[0]);
        long b = Long.parseLong(args[1]);
        long c = Long.parseLong(args[2]);

        long maxSide = Math.max(a, Math.max(b, c));
        long maxSquared = maxSide * maxSide;
        long remainingSquaredSum = a * a + b * b + c * c - maxSquared;
        System.out.println(a > 0 && b > 0 && c > 0 && maxSquared == remainingSquaredSum);
    }
}
